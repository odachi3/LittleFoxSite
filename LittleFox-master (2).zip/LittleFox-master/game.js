var config =
{
    width: 1300,
    height: 615,
    backgroundColor: 0x000000,
    scene: [Scene1, Scene2]
} 
//TAMANHO DA TELA DO JOGO: 270
var game = new Phaser.Game(config); 